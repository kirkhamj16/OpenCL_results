echo "Beginning 100k iterations"
cd src/build/bin/
./litmus_exe -D MEM_STRESS=1 -i 100000 ../../MP_clean
cd ../../..
