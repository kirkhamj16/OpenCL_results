void test_barrier(__global atomic_int *x, int num_threads) {
  int max_iters = 1000;
  int iters = 0;
  int val = atomic_fetch_add_explicit(x, 1, memory_order_relaxed, memory_scope_device);
  while (iters < max_iters && val != num_threads) {
    val = atomic_load_explicit(x, memory_order_relaxed, memory_scope_device);
    iters += 1;
  }
  return;  
}


#define TEST_THREAD(l, w) (lid == l && wgid == w)
#define TESTING_WARP(l, w) (wgid == w && (lid/dwarp_size == l/dwarp_size))


#ifndef SCRATCH_LOC
#define SCRATCH_LOC (scratch_locations[get_global_id(0)])
#endif

#ifndef MEM_STRESS
#define MEM_STRESS 0
#endif

#ifndef STRESS_ITERATIONS
#define STRESS_ITERATIONS 512
#endif
