
#include "stdio.h"
#include <vector>
#include <iostream>
#ifdef _WIN32
#include "getopt_win.h"
#else
#include "getopt.h"
#endif
#include "cl_execution.h"
#include <chrono>
#include <fstream>
#include <algorithm>
#include <stdlib.h>
#include "functiondefs.h"
#include <string.h>
#include <CL/cl.hpp>
#include <time.h>

#define SIZE 1024
#define NANOSEC 1000000000LL

std::string INPUT_FILE;
std::string kernel_include = "../../"; 

int LIST = 0;
int PLATFORM_ID = 0;
int DEVICE_ID = 0;
int QUIET = 0;
int USE_CHIP_CONFIG = 1;

int ITERATIONS = 1000;
int X_Y_STRIDE = 32;
int PATCH_SIZE = 32;
int CONC_STRESS = 1;

struct TestConfig
{
  int hist_size;
  std::vector<std::string> hist_strings;
  int output_size;
};

struct ChipConfig
{
  int max_local_size;
  int min_local_size;
  int occupancy_est;
  int warp_size;
};

std::map<std::string, ChipConfig> ChipConfigMaps;

void populate_ChipConfigMaps()
{
  ChipConfig defaultChipConfig = { 256, 128, 32, 1 };
  ChipConfig IntelNeo = { 256, 1, 16, 8 };
  
  ChipConfigMaps["default"] = defaultChipConfig;
  ChipConfigMaps["Intel(R) Gen9 HD Graphics NEO"] = IntelNeo;
}

//From IWOCL tutorial (needs attribution)
cl_platform_id *platforms;

unsigned getDeviceList(std::vector<std::vector<cl_device_id>> &devices, int &err) {
  CLW_CLASS_WRAPPER;
  // Get list of platforms
  cl_uint num_plats = 0;
  err = CLWGetPlatformIDs(0, NULL, &num_plats);
  platforms = (cl_platform_id *)malloc(sizeof(cl_platform_id)*num_plats);
  CLWGetPlatformIDs(num_plats, platforms, NULL);
  std::cout << platforms[1];
  if (err < 0) {
    return err;
  }

 
  for (unsigned int i = 0; i < 1; i++) {
    cl_uint num_devices = 0;
    err = CLWGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, 0, NULL, &num_devices);
    if (err < 0) {
      return err;
    }
    cl_device_id * plat_devices = (cl_device_id *)malloc(sizeof(cl_device_id)*num_devices);
    CLWGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, num_devices, plat_devices, NULL);

    std::vector<cl_device_id> to_push;
    for (unsigned int j = 0; j < num_devices; j++) {
      to_push.push_back(plat_devices[j]);
    }
    devices.push_back(to_push);
  }
  return devices.size();
}

#if !defined(ANDROID)

void usage(int argc, char *argv[])
{
  fprintf(stderr, "usage: %s [-l] [-q] [-p platform_id] [-d device_id] [-o output-file] litmus-test-directory\n", argv[0]);
}

std::string parse_args(int argc, char *argv[])
{
  int c;
  const char *skel_opts = "p:d:D:i:clqo:";
  char *opts;
  int len = 0;
  char *end;
  // LEFT OFF HERE, FIGURE OUT T
  std::stringstream kernel_defs;

  len = strlen(skel_opts) + 1;
  opts = (char *)calloc(len, sizeof(char));
  if (!opts)
  {
    fprintf(stderr, "Unable to allocate memory\n");
    exit(EXIT_FAILURE);
  }

  strcat(opts, skel_opts);

  while ((c = getopt(argc, argv, opts)) != -1)
  {
    switch (c)
    {
    case 'D':
      kernel_defs << "-D " << optarg << " ";
      if (strstr(optarg, "X_Y_STRIDE") != NULL) {
	char *tok = strtok(optarg, "=");
	tok = strtok(NULL, "=");
	X_Y_STRIDE = atoi(tok);
      }
      else if (strstr(optarg, "PATCH_SIZE") != NULL) {
	char *tok = strtok(optarg, "=");
	tok = strtok(NULL, "=");
	PATCH_SIZE = atoi(tok);
      }
      else if (strstr(optarg, "CONC_STRESS") != NULL) {
	char *tok = strtok(optarg, "=");
	tok = strtok(NULL, "=");
	CONC_STRESS = atoi(tok);
      }
      break;
    case 'q':
      QUIET = 1;
      break;
    case 'c':
      USE_CHIP_CONFIG = 1;
      break;
    case 'i':
      errno = 0;
      ITERATIONS = strtol(optarg, &end, 10);
      if (errno != 0 || *end != '\0')
      {
        fprintf(stderr, "Invalid iterations '%s'. An integer must be specified.\n", optarg);
        exit(EXIT_FAILURE);
      }
      break;
    case 'l':
      LIST = 1;
      break;
    case 'p':
      errno = 0;
      PLATFORM_ID = strtol(optarg, &end, 10);
      if (errno != 0 || *end != '\0')
      {
        fprintf(stderr, "Invalid platform id device '%s'. An integer must be specified.\n", optarg);
        exit(EXIT_FAILURE);
      }
      break;
    case 'd':
      errno = 0;
      DEVICE_ID = strtol(optarg, &end, 10);
      if (errno != 0 || *end != '\0')
      {
        fprintf(stderr, "Invalid device id device '%s'. An integer must be specified.\n", optarg);
        exit(EXIT_FAILURE);
      }
      break;
    case '?':
      usage(argc, argv);
      exit(EXIT_FAILURE);
      break;
    }
  }

  if (LIST != 1)
  {
    if (optind < argc)
    {
      INPUT_FILE = argv[optind];
    }
    else
    {
      usage(argc, argv);
      exit(EXIT_FAILURE);
    }
  }
  free(opts);
  return kernel_defs.str();
}
#endif

cl_int get_kernels(CL_Execution &exec, int &err)
{
  CLW_CLASS_WRAPPER;


  exec.exec_kernels["litmus_test"] = CLWCreateKernel(exec.exec_program, "litmus_test", &err);

  exec.exec_kernels["check_outputs"] = CLWCreateKernel(exec.exec_program, "check_outputs", &err);

  return err;
}

TestConfig parse_config(const std::string &config_str) {
  std::stringstream config_stream(config_str);
  TestConfig ret;
  std::string title, ignore;

  std::getline(config_stream, title);

  std::getline(config_stream, ignore);
  std::getline(config_stream, ignore);
  ret.hist_size = std::stoi(ignore);

  for (int i = 0; i < ret.hist_size; i++) {
    std::string out_desc;
    std::getline(config_stream, out_desc);
    ret.hist_strings.push_back(out_desc);
  }
  ret.hist_strings.push_back("errors: ");
  ret.hist_size++;
  std::getline(config_stream, ignore); // "num outputs"
  std::getline(config_stream, ignore);
  ret.output_size = std::stoi(ignore);
  return ret;
}

// test is kernel string with the testing_common.h as part of the string
 int run_test(std::string test, std::string test_config, int iterations, int x_y_stride, int platform_id, int device_id, std::string options, std::string &ret_info) {

  CLW_CLASS_WRAPPER;
  CL_Execution exec;
  std::stringstream return_str;
  ChipConfig cConfig;
  int err = 0;

  srand(time(NULL));

  populate_ChipConfigMaps();
  std::vector<std::vector<cl_device_id>> devices;
  getDeviceList(devices, err);
  check_ocl(err);

  if (platform_id >= devices.size())
  {
    return_str << "ERROR: Invalid platform id (" << platform_id << ") \n";
    ret_info = return_str.str();
    return -1;
  }

  if (device_id >= devices[platform_id].size())
  {
    return_str << "ERROR: Invalid device id (" << device_id << ") \n";
    ret_info = return_str.str();
    return -1;
  }

  populate_ChipConfigMaps();
  exec.exec_device = devices[PLATFORM_ID][DEVICE_ID];
  exec.exec_platform = platforms[PLATFORM_ID];

  return_str << "Using Device: " << exec.getExecDeviceName(err) << "\n";
  check_ocl(err);

  return_str << "Driver Version: " << exec.getExecDriverVersion(err) << "\n";
  check_ocl(err);


  if (ChipConfigMaps.find(exec.getExecDeviceName(err).c_str()) == ChipConfigMaps.end())
  {
    return_str << "using chip config: default\n";
    cConfig = ChipConfigMaps["default"];
  }
  else
  {
    return_str << "using chip config: " << exec.getExecDeviceName(err) << "\n";
    cConfig = ChipConfigMaps[exec.getExecDeviceName(err).c_str()];
    check_ocl(err);

  }

  cl_context_properties props[3] = { CL_CONTEXT_PLATFORM, (cl_context_properties)exec.exec_platform, 0 };
  exec.exec_context = CLWCreateContext(props, 1, &(exec.exec_device), NULL, NULL, &err);
  check_ocl(err);
  exec.exec_queue = CLWCreateCommandQueue(exec.exec_context, exec.exec_device, NULL, &err);
  check_ocl(err);

  std::string tmp_str;
  err = exec.compile_kernel(test.c_str(), "", options, err, tmp_str);
  return_str << tmp_str;
  check_ocl(err);

  int occupancy = cConfig.occupancy_est;
  int max_local_size = cConfig.max_local_size;

  int max_global_size = max_local_size * occupancy;
  err = get_kernels(exec, err);
  check_ocl(err);

  TestConfig cfg = parse_config(test_config);

  cl_mem dga = CLWCreateBuffer(exec.exec_context, CL_MEM_READ_WRITE, sizeof(cl_int) * (SIZE), NULL, &err);
  check_ocl(err);
  cl_mem dgna = CLWCreateBuffer(exec.exec_context, CL_MEM_READ_WRITE, sizeof(cl_int) * (SIZE), NULL, &err);
  check_ocl(err);
  cl_mem doutput = CLWCreateBuffer(exec.exec_context, CL_MEM_READ_WRITE, sizeof(cl_int) * ((cfg.output_size)), NULL, &err);
  check_ocl(err);
  cl_mem dresult = CLWCreateBuffer(exec.exec_context, CL_MEM_READ_WRITE, sizeof(cl_int) * (1), NULL, &err);
  check_ocl(err);
  cl_mem dscratchpad = CLWCreateBuffer(exec.exec_context, CL_MEM_READ_WRITE, sizeof(cl_int) * (1<<21), NULL, &err);
  check_ocl(err);
  cl_mem dbarrier_mem = CLWCreateBuffer(exec.exec_context, CL_MEM_READ_WRITE, sizeof(cl_int) * (512), NULL, &err);
  check_ocl(err);
  cl_mem dscratchpad_location = CLWCreateBuffer(exec.exec_context, CL_MEM_READ_WRITE, sizeof(cl_int) * (max_global_size), NULL, &err);
  check_ocl(err);
  cl_int dwarp_size = cConfig.warp_size;

  cl_int hga[SIZE], hgna[SIZE], houtput[SIZE];
  cl_int hbarrier_mem[512];
  cl_int hresult;
  cl_int *hscratchpad_location = (cl_int *)malloc(sizeof(cl_int) * max_global_size);
  
  for (int i = 0; i < max_global_size; i++)
  {
    hscratchpad_location[i] = i;
  }

  for (int i = 0; i < SIZE; i++)
  {
    hga[i] = hgna[i] = houtput[i] = 0;
  }

  check_ocl(CLWSetKernelArg(exec.exec_kernels["litmus_test"], 0, sizeof(cl_mem), &dga));
  check_ocl(CLWSetKernelArg(exec.exec_kernels["litmus_test"], 1, sizeof(cl_mem), &dgna));
  check_ocl(CLWSetKernelArg(exec.exec_kernels["litmus_test"], 2, sizeof(cl_mem), &doutput));
  check_ocl(CLWSetKernelArg(exec.exec_kernels["litmus_test"], 3, sizeof(cl_mem), &dscratchpad));
  check_ocl(CLWSetKernelArg(exec.exec_kernels["litmus_test"], 8, sizeof(cl_int), &dwarp_size));
  check_ocl(CLWSetKernelArg(exec.exec_kernels["litmus_test"], 4, sizeof(cl_mem), &dbarrier_mem));
  check_ocl(CLWSetKernelArg(exec.exec_kernels["litmus_test"], 5, sizeof(cl_mem), &dscratchpad_location));

  check_ocl(CLWSetKernelArg(exec.exec_kernels["check_outputs"], 0, sizeof(cl_mem), &doutput));
  check_ocl(CLWSetKernelArg(exec.exec_kernels["check_outputs"], 1, sizeof(cl_mem), &dresult));

  auto now = std::chrono::high_resolution_clock::now();
  unsigned long long begin_time, end_time, time;
  begin_time = std::chrono::duration_cast<std::chrono::nanoseconds>(now.time_since_epoch()).count();
  
  int eff_scratch_size = 1<<20;
  int num_patches = eff_scratch_size / PATCH_SIZE;

  int *patch_assignments = (int *)malloc(CONC_STRESS * sizeof(int));

  for (int i = 0; i < CONC_STRESS; i++) {
    patch_assignments[i] = i;
  }
  
  cl_int dist = 128;
  cl_int location = 64;

  cl_int scratch_location = location;

  int *histogram = (int *)malloc(sizeof(int) * cfg.hist_size);

  for (int i = 0; i < cfg.hist_size; i++)
  {
    histogram[i] = 0;
  }

  for (int i = 0; i < iterations; i++)
  {
    
    // x_y_stride
    int stride = ((SIZE) / x_y_stride) - 1;
    cl_int x_loc = rand() % stride, y_loc;
    int offset = 0;
    
    do y_loc = rand() % stride; while (x_loc == y_loc);
    x_loc = x_loc * x_y_stride + offset;
    y_loc = y_loc * x_y_stride + offset;
    
    check_ocl(CLWSetKernelArg(exec.exec_kernels["litmus_test"], 6, sizeof(cl_int), &x_loc));
    check_ocl(CLWSetKernelArg(exec.exec_kernels["litmus_test"], 7, sizeof(cl_int), &y_loc));

    // set up ids
    // mod by zero, if max local size is same and min
    int warp_size = dwarp_size; // add to chip config before amd testing
    int local_size = 0;
    do local_size = (rand() % (max_local_size - cConfig.min_local_size)) + cConfig.min_local_size; while (local_size % warp_size != 0);
    int global_size = occupancy * local_size;
    int wg_count = global_size / local_size;
 
    // assign patches per stressing group)
    for (int i = 0; i < CONC_STRESS; i++) {
      patch_assignments[i] = rand() % num_patches;
    }
    // assign individual locations
    int per_group = (global_size / CONC_STRESS) + 1;
    if (global_size % CONC_STRESS == 0) {
      per_group = per_group - 1;
    }
    
    for (int i = 0; i < global_size; i++) {
      int group = i / per_group;
      hscratchpad_location[i] = patch_assignments[group] * PATCH_SIZE + (rand() % PATCH_SIZE);
    }

    err = CLWEnqueueWriteBuffer(exec.exec_queue, dscratchpad_location, CL_TRUE, 0, sizeof(cl_int) * (global_size), hscratchpad_location, 0, NULL, NULL);
    check_ocl(err);
    
    err = CLWEnqueueWriteBuffer(exec.exec_queue, dga, CL_TRUE, 0, sizeof(cl_int) * (SIZE), hga, 0, NULL, NULL);
    check_ocl(err);

    err = CLWEnqueueWriteBuffer(exec.exec_queue, dgna, CL_TRUE, 0, sizeof(cl_int) * (SIZE), hgna, 0, NULL, NULL);
    check_ocl(err);

    err = CLWEnqueueWriteBuffer(exec.exec_queue, doutput, CL_TRUE, 0, sizeof(cl_int) * (cfg.output_size), houtput, 0, NULL, NULL);
    check_ocl(err);

    err = CLWEnqueueWriteBuffer(exec.exec_queue, dbarrier_mem, CL_TRUE, 0, sizeof(cl_int) * (512), hbarrier_mem, 0, NULL, NULL);
    check_ocl(err);

    err = CLWFinish(exec.exec_queue);
    check_ocl(err);

    const size_t global_size_t = global_size;
    const size_t local_size_t = local_size;

    err = CLWEnqueueNDRangeKernel(exec.exec_queue, exec.exec_kernels["litmus_test"], 1, NULL, &global_size_t, &local_size_t, 0, NULL, NULL);
    check_ocl(err);

    err = CLWFinish(exec.exec_queue);

    check_ocl(err);

    const size_t global_size_t2 = 1;
    const size_t local_size_t2 = 1;
    err = CLWEnqueueNDRangeKernel(exec.exec_queue, exec.exec_kernels["check_outputs"], 1, NULL, &global_size_t2, &local_size_t2, 0, NULL, NULL);
    check_ocl(err);

    err = CLWEnqueueReadBuffer(exec.exec_queue, dresult, CL_TRUE, 0, sizeof(cl_int) * 1, &hresult, 0, NULL, NULL);
    check_ocl(err);

    histogram[hresult]++;
  }

  now = std::chrono::high_resolution_clock::now();
  end_time = std::chrono::duration_cast<std::chrono::nanoseconds>(now.time_since_epoch()).count();
  time = end_time - begin_time;
  float time_float = static_cast<float>(time) / static_cast<float>(NANOSEC);

  return_str << std::endl << "RESULTS: " << std::endl;
  return_str << "-------------------" << std::endl;
  for (int i = 0; i < cfg.hist_size; i++) {
    return_str << cfg.hist_strings[i] << histogram[i] << std::endl;
  }
  
  return_str << std::endl;
  return_str << "RATES" << std::endl;
  return_str << "-------------------" << std::endl;
  return_str << "tests          : " << iterations << std::endl;
  return_str << "time (seconds) : " << time_float << std::endl;
  return_str << "tests/sec      : " << static_cast<float>(iterations) / time_float << std::endl;
  
  return_str << std::endl;
  

  free(platforms);
  free(patch_assignments);
  free(histogram);
  ret_info = return_str.str();
  return 1;
}

//From the IWOCL tutorial (needs attribution)
std::string loadFile(const char* input, size_t *len) {
  std::ifstream stream(input);
  if (!stream.is_open()) {
    std::cout << "Cannot open file: " << input << std::endl;
#if defined(_WIN32) && !defined(__MINGW32__)
    system("pause");
#endif
    exit(1);
  }

  std::string ret = std::string(
    std::istreambuf_iterator<char>(stream),
    (std::istreambuf_iterator<char>()));
  *len = ret.size();
  return ret;
}

#if !defined(ANDROID)
int main(int argc, char *argv[])
{

  int err = 0;
  std::string opts;

  if (argc == 1)
  {
    usage(argc, argv);
    exit(1);
  }

  opts = parse_args(argc, argv);

  std::string kernel_file = INPUT_FILE + "/kernel.cl";
  std::string test_config_file = INPUT_FILE + "/config.txt";

  std::string to_print;
  size_t f_len;
  std::string tconfig = loadFile(test_config_file.c_str(), &f_len);
  std::string src0 = loadFile(kernel_file.c_str(), &f_len);
  std::string t_common = kernel_include + "/testing_common.h";
  std::string src1 = loadFile(t_common.c_str(), &f_len);
  std::string nvidia_atomics = kernel_include + "/nvidia_atomics.h";
  std::string src2 = loadFile(nvidia_atomics.c_str(), &f_len);
  std::string final_source = src2 + src1 + src0;

  run_test(final_source, tconfig, ITERATIONS, X_Y_STRIDE, PLATFORM_ID, DEVICE_ID, opts, to_print);
  std::cout << to_print;
  return 1;
}
#endif
