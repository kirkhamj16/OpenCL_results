cd src
mkdir build
cd build
cmake ..
make
cd ../..
